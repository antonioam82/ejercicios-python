#IMPORTAR RECURSOS.
import cv2
import os
import matplotlib.pyplot as plt
os.chdir(r'C:\Users\Antonio\Documents')

#CARGAR IMAGEN DE PRUEBA.
image = cv2.imread('test.jpg')

#CONVERTIR A ESCALA DE GRISES.
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
print(gray_image)

#GENERAR HISTOGRAMA.
histogram = cv2.calcHist([gray_image], [0], None, [256], [0, 256])
plt.title("Histagrama")
plt.hist(histogram,bins=256)
plt.grid(True)
plt.show()


#REPETIR PROCESO PARA "data1.jpg".
image = cv2.imread('data1.jpg')
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
histogram1 = cv2.calcHist([gray_image], [0], None, [256], [0, 256])


#PROCESO PARA "data2.jpg".
image = cv2.imread('data2.jpg')
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
histogram2 = cv2.calcHist([gray_image], [0], None, [256], [0, 256])
 
c1, c2 = 0, 0
 
#DISTANCIA EUCLIDEA ENTRE "test.jpg" Y "data1.jpg".
i = 0
while i<len(histogram) and i<len(histogram1):
    c1+=(histogram[i]-histogram1[i])**2
    i+=1

	
c1 = c1**(1/2)
print("DISTANCIA tets.jpg\data1.jpg: ",c1)

#DISTANCIA EUCLIDEA ENTRE "test.jpg" Y "data2.jpg".
i = 0
while i<len(histogram) and i<len(histogram2):
    c2+=(histogram[i]-histogram2[i])**2
    i+=1

c2 = c2**(1/2)
print("DISTANCIA tets.jpg\data2.jpg: ",c2)

if(c1<c2):
    print("data1.jpg es más parecida a test.jpg que data2.jpg.")
else:
    print("data2.jpg es más parecida a test.jpg que data1.jpg.")





    
          
